#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <fcntl.h>
#include "data_struct.h"
#include "data_read.h"
#include "generate_weights.h"

int test(struct data *allData, int numIn, int numHid, int numOut, int numSample, double **weightIH, double **weightHO) {
    int i, j;
    double Sum_Hidden[numSample][numHid], Hidden_Activation[numSample][numHid];
    double Sum_Output[numSample][numOut], Output[numSample][numOut];
    double finalOut[numSample];
    double accuracy = 0;

    // Forward propagation
    for(int sample = 0; sample < numSample; sample++) {
		
        for(j = 1; j <= numHid; j++) {
            Sum_Hidden[sample][j] = weightIH[0][j]; // Bias value
            for(i = 1; i <= numIn; i++) {
                Sum_Hidden[sample][j] += allData[sample].feat[i] * weightIH[i][j];
            }
            Hidden_Activation[sample][j] = 1.0 / (1.0 + exp(-Sum_Hidden[sample][j])); // Sigmoidal function
        }
		
		Sum_Output[sample][0] = weightHO[0][0]; // Bias value
		for(j = 1; j <= numHid; j++) {
			Sum_Output[sample][0] += Hidden_Activation[sample][j] * weightHO[j][0];
		}
		Output[sample][0] = 1.0 / (1.0 + exp(-Sum_Output[sample][0]));   // Sigmoidal outputs

		if (Output[sample][0] >= 0.5) {
			finalOut[sample] = 1;
		} else {
			finalOut[sample] = 0;
		}
		
       if (allData[sample].out[0] == finalOut[sample]) accuracy++;
    }
	
	accuracy /= numSample;
	printf("Validation accuracy: %f\n", accuracy);
    return 1;
}


