#ifndef SERIAL_TRAINING
#define SERIAL_TRAINING

    int serial(struct data *allData, int numIn, int numHid, int numOut, int numSample, int epochMax, double learningRate, double **WeightIH, double **WeightHO);

#endif