#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "data_struct.h"
#include "data_read.h"
#include "generate_weights.h"
#include "serial.h"
#include <omp.h>
#include "parallel.h"
#include "validation.h"

int main() {
	int layer_in = 1000;
	int layer_hid;
	int layer_out = 1;
	int epochs;
	float lrate;
	double time, end_time;
	struct data *training_data, *validation_data;
	int observations_training, observations_validation;
	double **weights1, **weights2;
	char input[10];
	
	
	printf("Input the number of neurons in the hidden layer: ");
	fgets(input, 10, stdin);
	layer_hid = atoi(input);
	if (layer_hid <= 0 || layer_hid > 1000) {
		perror("Error. The input value is invalid");
		exit(1);
	}
	
	printf("Input the learning rate value: ");
	fgets(input, 10, stdin);
	lrate = atof(input);
	if (lrate <= 0.0 || lrate >= 1.0) {
		perror("Error. The input value is invalid");
		exit(1);
	}
	
	printf("Input the number of epochs: ");
	fgets(input, 10, stdin);
	epochs = atoi(input);
	if (epochs <= 0) {
		perror("Error. The input value is invalid");
		exit(1);
	}
	
	printf("Choose serial (s) or parallel (p): ");
	fgets(input, 10, stdin);
	if (strcmp(input, "s\n") != 0 && strcmp(input, "p\n") != 0) {
		perror("Error. The input value is invalid");
		exit(1);
	}
	
	time = omp_get_wtime();
	printf("Reading training data...\n");
	training_data = read_data(layer_in, layer_out, "moviedata_training_3000.csv", &observations_training);
	printf("Reading validation data...\n");
	validation_data = read_data(layer_in, layer_out, "moviedata_validation_3000.csv", &observations_validation);
	printf("Generating weights (1/2)...\n");
	weights1 = gen_weights(layer_in, layer_hid, 100);
	printf("Generating weights (2/2)...\n");
	weights2 = gen_weights(layer_hid, layer_out, 200);
	
	printf("Neural network training...\n");
	if (strcmp(input, "s\n") == 0) {
		serial(training_data, layer_in, layer_hid, layer_out, observations_training, epochs, lrate, weights1, weights2);
	} else {
		parallel(training_data, layer_in, layer_hid, layer_out, observations_training, epochs, lrate, weights1, weights2);
	}
	
	printf("\nNeural network test...\n");
	test(validation_data, layer_in, layer_hid, layer_out, observations_validation, weights1, weights2);
	
	end_time = omp_get_wtime() - time; // Should only be used on the serial code
	printf("\nTotal time = %lf\n", end_time);
	printf("Finished.\n");
}
