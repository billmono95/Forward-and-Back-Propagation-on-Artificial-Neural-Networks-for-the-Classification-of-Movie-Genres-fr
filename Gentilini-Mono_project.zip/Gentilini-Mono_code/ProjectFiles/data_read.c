#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <ctype.h>
#include "data_struct.h"

struct data *allocate_memory(FILE *file, struct data *data, int block_dim, int struct_dim, int *allocated_mem, int num_feat, int num_out, int *n_obs);

struct data *read_data(int num_feat, int num_out, char *file_name, int *n_obs) {
	struct data *observ = NULL;
	int block_num = 10;
	int struct_dim = sizeof(struct data);
	int block_dim = block_num * struct_dim;
	int allocated_mem;
	FILE *file;
	
	observ = malloc((size_t)block_dim);
	if (observ == NULL) {
		perror("Error. Not enough memory");
		exit(1);
	}
	allocated_mem = block_dim;
	
	file = fopen(file_name, "r");
	if (file == NULL) {
		perror("Error. The specified file cannot be opened");
		exit(1);
	}
	
	observ = allocate_memory(file, observ, block_dim, struct_dim, &allocated_mem, num_feat, num_out, n_obs);
	fclose(file);
	return observ;
}

struct data *allocate_memory(FILE *file, struct data *data, int block_dim, int struct_dim, int *allocated_mem, int num_feat, int num_out, int *n_obs) {
	*n_obs = -1;
	int used_mem = 0;
	char row[20000];
	
	while (fgets(row, 20000, file) != NULL){
		if (*n_obs == -1) { // Skip the first row (variable names, see the .csv files)
			*n_obs += 1;
			continue;
		}
		
		used_mem += struct_dim;
		if (used_mem > *allocated_mem) {
			*allocated_mem += block_dim;
			data = realloc(data, (size_t)(*allocated_mem));
			if (data == NULL) {
				perror("Error. Not enough memory");
				exit(1);
			}
		}
		
		data[*n_obs].feat = (double *)malloc(sizeof(double) * (num_feat + 1)); // Add 1 in order to account for the bias
		data[*n_obs].out = (double *)malloc(sizeof(double) * (num_out));
		if (data[*n_obs].feat == NULL || data[*n_obs].out == NULL) {
			perror("Error. Not enough memory");
			exit(1);
		}
		data[*n_obs].feat[0] = 1;
		
		int counter = 1;
		char *character = row;
		while (*character) {
			if (isdigit(*character)) {
				double value = strtod(character, &character);
				if (counter <= num_feat) {
					data[*n_obs].feat[counter] = value;
					counter += 1;
				} else {
					data[*n_obs].out[counter - num_feat - 1] = value;
					counter += 1;
				}
			}
			character += 1;
		}
		
		*n_obs += 1;
	}
	
	return data;
}