#ifndef DATA_STRUCT
#define DATA_STRUCT

    struct data
    {
        double *feat;
        double *out;
    };

#endif