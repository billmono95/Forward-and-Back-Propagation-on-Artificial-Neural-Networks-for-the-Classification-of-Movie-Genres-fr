#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <fcntl.h>
#include <omp.h>
#include "data_struct.h"
#include "data_read.h"
#include "generate_weights.h"

int parallel2(struct data *allData, int numIn, int numHid, int numOut, int numSample, int epochMax, double learningRate, double **WeightIH, double **WeightHO) {
    int i, j, num_epoch;
    double Sum_Hidden[numSample][numHid], Hidden_Activation[numSample][numHid];
    double Sum_Output[numSample][numOut], Output[numSample][numOut];
    double Delta_Output[numSample][numOut], Partial_DeltaH[numHid], Delta_Hidden[numSample][numHid];
    double Delta_WeightIH[numIn][numHid], Delta_WeightHO[numHid][numOut];
    double lossError, accuracy = 0;
    double parallel_time;
    double parallel_t = 0.0;

    for(num_epoch = 0; num_epoch < epochMax; num_epoch++) {
        parallel_time = omp_get_wtime();
		
        lossError = 0.0;
        accuracy = 0.0;
		
		for(int sample = 0; sample < numSample; sample++) {
		#pragma omp parallel for private(j, i)        
			for (j = 1; j <= numHid; j++) { // Hidden units activations
                // printf("NUMBER SAMPLE %d iteration INPUT WEIGHT %d is processed by %d\n ",sample, j , omp_get_thread_num());
                Sum_Hidden[sample][j] = WeightIH[0][j]; // Hidden layer bias
                for (i = 1; i <= numIn; i++) {
                    Sum_Hidden[sample][j] += allData[sample].feat[i] * WeightIH[i][j];
                }
                Hidden_Activation[sample][j] = 1.0 / (1.0 + exp(-Sum_Hidden[sample][j])); // Sigmoidal activation function for the hidden layer
                // printf("NUMBER SAMPLE %d iteration ACTIVATION %d is processed by %d\n ",sample, j , omp_get_thread_num());
            }
			
			Sum_Output[sample][0] = WeightHO[0][0]; // Output layer bias
			#pragma omp parallel for private(j)            
			for (j = 1; j <= numHid; j++) {
				Sum_Output[sample][0] += Hidden_Activation[sample][j] * WeightHO[j][0];
				// printf("NUMBER SAMPLE %d iteration OUTPUT %d is processed by %d\n ",sample, j , omp_get_thread_num());
			}

			Output[sample][0] = 1.0 / (1.0 + exp(-Sum_Output[sample][0]));   // Sigmoidal Outputs
			lossError -= (allData[sample].out[0] * log(Output[sample][0]) + (1.0 - allData[sample].out[0]) * log(1.0 - Output[sample][0]));    // Cross-Entropy 
			Delta_Output[sample][0] = allData[sample].out[0] - Output[sample][0];    // Delta for Sigmoidal Outputs, Cross-Entropy lossError

			if (fabs(allData[sample].out[0] - Output[sample][0]) < 0.5) accuracy++;
			
			#pragma omp parallel for private(j, i, Partial_DeltaH)
            for (j = 1; j <= numHid; j++) { // Back propagation
				Partial_DeltaH[j] = 0.0;
				Partial_DeltaH[j] += WeightHO[j][0] * Delta_Output[sample][0];
				Delta_Hidden[sample][j] = Partial_DeltaH[j] * Hidden_Activation[sample][j] * (1.0 - Hidden_Activation[sample][j]);
				// printf("NUMBER SAMPLE %d iteration PARTIAL DERIVATIVE %d is processed by %d\n ",sample, j , omp_get_thread_num());
            }
        }
		
		for (int sample = 0; sample < numSample; sample++) {
			#pragma omp parallel for private(j, i)
            for (i = 0; i <= numIn; i++) { // Weights update
                for (j = 1; j <= numHid; j++) {
                    Delta_WeightIH[i][j] += allData[sample].feat[i] * Delta_Hidden[sample][j];
                    WeightIH[i][j] += learningRate * Delta_WeightIH[i][j] / numSample;
                    Delta_WeightIH[i][j] = 0.0;
                    
                }
            }
			
			#pragma omp parallel for private(j)    
			for (j = 0; j <= numHid; j++) {
				Delta_WeightHO[j][0] += Hidden_Activation[sample][j] * Delta_Output[sample][0];
				WeightHO[j][0] += learningRate * Delta_WeightHO[j][0] / numSample;
				Delta_WeightHO[j][0] = 0.0;
				// printf("NUMBER SAMPLE %d iteration END %d is processed by %d\n ",sample, j , omp_get_thread_num());
            }
        }

		lossError = lossError / numSample;
		accuracy = accuracy / numSample;
		
		parallel_t += omp_get_wtime() - parallel_time;
		
		if (num_epoch % 100 == 0) {
            fprintf(stdout, "\nEpoch %-5d:\tLoss error = %f\tTraining accuracy = %f", num_epoch, lossError, accuracy);
		}
	}
	
	printf("\nTime code not parallelizable = %lf\n", parallel_t);
	
	return 1;
}


