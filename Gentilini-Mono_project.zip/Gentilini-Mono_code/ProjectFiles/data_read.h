#ifndef DATA_READ
#define DATA_READ

    struct data *read_data(int num_feat, int num_out, char *file_name, int *n_obs);

#endif