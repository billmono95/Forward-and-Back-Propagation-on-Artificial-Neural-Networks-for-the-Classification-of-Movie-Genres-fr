#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <ctype.h>

double **gen_weights(int n_row, int n_col, int starting_seed) {
	double **rnd_weights = NULL;
	n_row++; // Account for the bias
	n_col++;
	
	rnd_weights = malloc(sizeof(double *) * n_row);
	for (int i = 0; i < n_row; i++) {
		rnd_weights[i] = malloc(sizeof(double) * n_col);
	}
	
	srand((unsigned)starting_seed);
	for (int r = 0; r < n_row; r++) {
		for (int c = 0; c < n_col; c++) {
			double rnd_value = (double)rand() / (double)((unsigned)RAND_MAX + 1); // Random float value between 0 and 1
			if (((double)rand() / (double)((unsigned)RAND_MAX + 1)) < 0.5) rnd_value = -rnd_value; // Generate a negative sign randomly
			rnd_weights[r][c] = rnd_value;
		}
	}
	
	return rnd_weights;
}