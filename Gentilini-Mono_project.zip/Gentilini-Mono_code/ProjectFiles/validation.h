#ifndef VALIDATION
#define VALIDATION

	int test(struct data *allData, int numIn, int numHid, int numOut, int numSample, double **weightIH, double **weightHO);

#endif