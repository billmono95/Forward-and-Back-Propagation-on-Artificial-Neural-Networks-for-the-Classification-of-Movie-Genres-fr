#ifndef GENERATE_WEIGHTS
#define GENERATE_WEIGHTS

    double **gen_weights(int n_row, int n_col, int starting_seed);

#endif