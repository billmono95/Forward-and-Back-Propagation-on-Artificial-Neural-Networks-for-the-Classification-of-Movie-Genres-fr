#ifndef PARALLEL_TRAINING
#define PARALLEL_TRAINING
  
    int parallel(struct data *allData, int numIn, int numHid, int numOut, int numSample, int epochMax, double learningRate, double **WeightIH, double **WeightHO);

#endif 